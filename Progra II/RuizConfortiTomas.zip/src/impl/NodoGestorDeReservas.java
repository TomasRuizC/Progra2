package impl;

public class NodoGestorDeReservas {
    int reserva;
    int pasajero;
    int vuelo;
    int asiento;
    int fecha;
    NodoGestorDeReservas sig;
}
