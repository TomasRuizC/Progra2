package impl;

import api.ListaTDA;

public class NodoAlumno {
    int info;
    ListaTDA notas;
    NodoAlumno sig;
}
