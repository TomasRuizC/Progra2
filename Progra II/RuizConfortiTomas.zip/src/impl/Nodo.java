// Realizado por Lussoro Nicolás y Ruiz Conforti Tomás
package impl;

public class Nodo {
    
    int info;
    Nodo sig;

}
